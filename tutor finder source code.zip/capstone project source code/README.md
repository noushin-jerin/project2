# Tutor-Finder

This is a web-application which helps students find tutors based on their input location and subject.
This app uses PHP For backend and MySQL database.

# Importance/USP

It is an age old problem that a student has a tough time finding the teacher when required, thus this project present a easy to use solution of finding a teacher when required using our application. It also provide privacy to the teacher so that he can select the hours during which the students can meet him/her and the location where they can find the tutor.

# Features

* A student can search for tutor when he is only logged in.

* When logged in student can also request tutor of a subject.

* There is space for teacher to update when he logs in.

* There are features such as FAQ's included.

* Database file tutor.sql is also included.
